Mindstrate MCP Server — offline installer (version 0.1.0)
=============================================================

Requirements: Node.js 18 or newer.

Linux / macOS:
  bash install.sh
  # follow prompts (Team Server URL, API Key, AI tool)

Windows:
  Right-click install.ps1 -> "Run with PowerShell"
  (or from a PowerShell prompt:  .\install.ps1)

The installer copies mindstrate-mcp.js into ~/.mindstrate-mcp/ and
wires it into the AI tool you pick (OpenCode / Cursor / Claude Desktop).
Restart the AI tool after install to pick up the new MCP config.

To upgrade: replace this folder with a newer one and re-run the installer.
